-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 22-03-2010 a las 12:57:26
-- Versión del servidor: 5.1.33
-- Versión de PHP: 5.2.9-2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `school`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumno`
--

CREATE TABLE IF NOT EXISTS `alumno` (
  `id_alumno` int(50) NOT NULL AUTO_INCREMENT,
  `carne` varchar(250) NOT NULL,
  `codigo_alumno` varchar(50) NOT NULL,
  `nombre_alumno` varchar(250) NOT NULL,
  `apellido` varchar(250) NOT NULL,
  `direccion` varchar(250) NOT NULL,
  `orden` varchar(250) NOT NULL,
  `registro` varchar(250) NOT NULL,
  `fecha` date NOT NULL,
  `telefono1` varchar(250) NOT NULL,
  `edad` varchar(200) NOT NULL,
  `sexo` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `padre` varchar(250) NOT NULL,
  `madre` varchar(250) NOT NULL,
  `encargado` varchar(250) NOT NULL,
  `profesion` varchar(500) NOT NULL,
  `labora` varchar(500) NOT NULL,
  `dpi` varchar(50) NOT NULL,
  `extendida` varchar(500) NOT NULL,
  `emergencia` varchar(250) NOT NULL,
  `telefono2` varchar(250) NOT NULL,
  `status` varchar(250) NOT NULL,
  `id_grado` int(50) NOT NULL,
  PRIMARY KEY (`id_alumno`),
  UNIQUE KEY `id_alumno` (`id_alumno`,`carne`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `alumno`
--

INSERT INTO `alumno` (`id_alumno`, `carne`, `codigo_alumno`, `nombre_alumno`, `apellido`, `direccion`, `orden`, `registro`, `fecha`, `telefono1`, `edad`, `sexo`, `email`, `padre`, `madre`, `encargado`, `profesion`, `labora`, `dpi`, `extendida`, `emergencia`, `telefono2`, `status`, `id_grado`) VALUES(1, '2010F1', '', 'Ana Carolina', 'Ramírez Méndez', '13 calle y 9na avenida, zona 1, edificio Ruth, apto 305', 'P17', '8,494', '2010-03-20', '2220-8310', '20 Años', 'F', 'anacaro@yahoo.es', 'Fidel Ramirez', 'Sonia Mendez', 'Fidel Ramirez', 'Perito Contador', 'Escuela Normal', '', 'Ciudad Flores, petén.', 'Padre', '5202-5436', 'status', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `areas_cursos`
--

CREATE TABLE IF NOT EXISTS `areas_cursos` (
  `id_area` int(50) NOT NULL AUTO_INCREMENT,
  `nombre_area` varchar(250) NOT NULL,
  `observacion_area` text NOT NULL,
  PRIMARY KEY (`id_area`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `areas_cursos`
--

INSERT INTO `areas_cursos` (`id_area`, `nombre_area`, `observacion_area`) VALUES(1, 'Comunicación y Lenguaje', '');
INSERT INTO `areas_cursos` (`id_area`, `nombre_area`, `observacion_area`) VALUES(2, 'Matemáticas', '');
INSERT INTO `areas_cursos` (`id_area`, `nombre_area`, `observacion_area`) VALUES(3, 'Ciencias Naturales', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `area_ocupacional`
--

CREATE TABLE IF NOT EXISTS `area_ocupacional` (
  `id_ocupacion` int(50) NOT NULL AUTO_INCREMENT,
  `nombre_ocupacion` varchar(250) NOT NULL,
  `observacion` varchar(500) NOT NULL,
  PRIMARY KEY (`id_ocupacion`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Volcar la base de datos para la tabla `area_ocupacional`
--

INSERT INTO `area_ocupacional` (`id_ocupacion`, `nombre_ocupacion`, `observacion`) VALUES(1, 'Agrícola', '');
INSERT INTO `area_ocupacional` (`id_ocupacion`, `nombre_ocupacion`, `observacion`) VALUES(2, 'Métales', '');
INSERT INTO `area_ocupacional` (`id_ocupacion`, `nombre_ocupacion`, `observacion`) VALUES(3, 'Eléctricidad', '');
INSERT INTO `area_ocupacional` (`id_ocupacion`, `nombre_ocupacion`, `observacion`) VALUES(4, 'Carpinteria', '');
INSERT INTO `area_ocupacional` (`id_ocupacion`, `nombre_ocupacion`, `observacion`) VALUES(5, 'Belleza', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `catedratico`
--

CREATE TABLE IF NOT EXISTS `catedratico` (
  `id_catedratico` int(50) NOT NULL AUTO_INCREMENT,
  `registro` varchar(100) NOT NULL,
  `nombre_catedratico` varchar(250) NOT NULL,
  `apellido` varchar(250) NOT NULL,
  `profesion` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `telefono` varchar(250) NOT NULL,
  `direccion` varchar(250) NOT NULL,
  `observacion` mediumtext NOT NULL,
  `status` varchar(250) NOT NULL,
  PRIMARY KEY (`id_catedratico`),
  UNIQUE KEY `id_catedratico` (`id_catedratico`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `catedratico`
--

INSERT INTO `catedratico` (`id_catedratico`, `registro`, `nombre_catedratico`, `apellido`, `profesion`, `email`, `telefono`, `direccion`, `observacion`, `status`) VALUES(1, 'cmemou', 'Juan Alberto', 'Xan Lopez', 'Ingeniero Industrial', 'jalberto@gmail.com', '3434-2323', 'Santa Elena, Flores, Petén.', '', 'Alta');
INSERT INTO `catedratico` (`id_catedratico`, `registro`, `nombre_catedratico`, `apellido`, `profesion`, `email`, `telefono`, `direccion`, `observacion`, `status`) VALUES(2, 'cmemou', 'Julia Julissa', 'Marleny Zamayoa', 'Psicologa', 'jjzamayoa@hotmail.com', '2323-0909', 'Calle Centro América, Ciudad Flores, Petén.', '', 'Alta');
INSERT INTO `catedratico` (`id_catedratico`, `registro`, `nombre_catedratico`, `apellido`, `profesion`, `email`, `telefono`, `direccion`, `observacion`, `status`) VALUES(3, 'cmemou', 'Jose Alvaro', 'Angel Zetina', 'Perito Agronomo', 'jzetina@yahoo.es', '9898-6754', 'Guatemala, Guatemala', '', 'Alta');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cursos`
--

CREATE TABLE IF NOT EXISTS `cursos` (
  `id_curso` int(50) NOT NULL AUTO_INCREMENT,
  `id_area` int(50) NOT NULL,
  `nombre_curso` varchar(250) NOT NULL,
  `capacidad` varchar(50) NOT NULL,
  `fecha` date NOT NULL,
  `status` varchar(250) NOT NULL,
  `id_grado` int(50) NOT NULL,
  `id_catedratico` int(50) NOT NULL,
  PRIMARY KEY (`id_curso`),
  UNIQUE KEY `id_curso` (`id_curso`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Volcar la base de datos para la tabla `cursos`
--

INSERT INTO `cursos` (`id_curso`, `id_area`, `nombre_curso`, `capacidad`, `fecha`, `status`, `id_grado`, `id_catedratico`) VALUES(1, 1, 'Idioma Ingles', '50', '2010-03-19', 'Alta', 1, 1);
INSERT INTO `cursos` (`id_curso`, `id_area`, `nombre_curso`, `capacidad`, `fecha`, `status`, `id_grado`, `id_catedratico`) VALUES(2, 2, 'Matemática', '40', '2010-03-19', 'Alta', 1, 3);
INSERT INTO `cursos` (`id_curso`, `id_area`, `nombre_curso`, `capacidad`, `fecha`, `status`, `id_grado`, `id_catedratico`) VALUES(3, 1, 'Mecanografia', '75', '2010-03-19', 'Alta', 1, 2);
INSERT INTO `cursos` (`id_curso`, `id_area`, `nombre_curso`, `capacidad`, `fecha`, `status`, `id_grado`, `id_catedratico`) VALUES(4, 1, 'Idioma Nativo', '55', '2010-03-22', 'Alta', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `examenes`
--

CREATE TABLE IF NOT EXISTS `examenes` (
  `id_examen` int(50) NOT NULL AUTO_INCREMENT,
  `examen` varchar(250) NOT NULL,
  `observacion` varchar(250) NOT NULL,
  `status` varchar(250) NOT NULL,
  `fecha_ingreso` date NOT NULL,
  PRIMARY KEY (`id_examen`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Volcar la base de datos para la tabla `examenes`
--

INSERT INTO `examenes` (`id_examen`, `examen`, `observacion`, `status`, `fecha_ingreso`) VALUES(1, '1er Trimestre', '', 'Alta', '2010-03-19');
INSERT INTO `examenes` (`id_examen`, `examen`, `observacion`, `status`, `fecha_ingreso`) VALUES(2, '2do Trimestre', '', 'Alta', '2010-03-19');
INSERT INTO `examenes` (`id_examen`, `examen`, `observacion`, `status`, `fecha_ingreso`) VALUES(3, '3er Trimestre', '', 'Alta', '2010-03-19');
INSERT INTO `examenes` (`id_examen`, `examen`, `observacion`, `status`, `fecha_ingreso`) VALUES(4, '1ra Recuperacion', '', 'Alta', '2010-03-19');
INSERT INTO `examenes` (`id_examen`, `examen`, `observacion`, `status`, `fecha_ingreso`) VALUES(5, '2da Recuperacion', '', 'Alta', '2010-03-19');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `faltas`
--

CREATE TABLE IF NOT EXISTS `faltas` (
  `id_falta` int(50) NOT NULL AUTO_INCREMENT,
  `id_alumno` int(50) NOT NULL,
  `falta` mediumtext NOT NULL,
  `tipo_falta` varchar(250) NOT NULL,
  `anio_falta` varchar(50) NOT NULL,
  `fecha_falta` date NOT NULL,
  PRIMARY KEY (`id_falta`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `faltas`
--

INSERT INTO `faltas` (`id_falta`, `id_alumno`, `falta`, `tipo_falta`, `anio_falta`, `fecha_falta`) VALUES(1, 1, 'Falta de Respeto al Catedratico de Educacion Musical', 'Media', '2010', '2010-03-20');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `grado`
--

CREATE TABLE IF NOT EXISTS `grado` (
  `id_grado` int(50) NOT NULL AUTO_INCREMENT,
  `fecha_grado` varchar(50) NOT NULL,
  `nombre` varchar(250) NOT NULL,
  `seccion` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY (`id_grado`),
  UNIQUE KEY `id_grado` (`id_grado`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `grado`
--

INSERT INTO `grado` (`id_grado`, `fecha_grado`, `nombre`, `seccion`, `status`) VALUES(1, '', 'Primer Grado', '', 'Alta');
INSERT INTO `grado` (`id_grado`, `fecha_grado`, `nombre`, `seccion`, `status`) VALUES(2, '', 'Segundo Grado', '', 'Alta');
INSERT INTO `grado` (`id_grado`, `fecha_grado`, `nombre`, `seccion`, `status`) VALUES(3, '', 'Tercer Grado', '', 'Alta');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notas`
--

CREATE TABLE IF NOT EXISTS `notas` (
  `id_nota` int(50) NOT NULL AUTO_INCREMENT,
  `id_alumno` int(50) NOT NULL,
  `id_grado` int(50) NOT NULL,
  `id_curso` int(50) NOT NULL,
  `id_bimestre` int(50) NOT NULL,
  `nota` int(50) NOT NULL,
  PRIMARY KEY (`id_nota`),
  UNIQUE KEY `id_nota` (`id_nota`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `notas`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ocupacion_alumno`
--

CREATE TABLE IF NOT EXISTS `ocupacion_alumno` (
  `id_relacion` int(50) NOT NULL AUTO_INCREMENT,
  `id_ocupacion` int(50) NOT NULL,
  `id_alumno` int(50) NOT NULL,
  PRIMARY KEY (`id_relacion`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `ocupacion_alumno`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reinscripcion`
--

CREATE TABLE IF NOT EXISTS `reinscripcion` (
  `id_reinscripcion` int(50) NOT NULL AUTO_INCREMENT,
  `id_alumno` int(50) NOT NULL,
  `carne` varchar(250) NOT NULL,
  `id_grado` int(50) NOT NULL,
  `observaciones` mediumtext NOT NULL,
  `fecha_reinscripcion` date NOT NULL,
  `encargado_reinscripcion` varchar(250) NOT NULL,
  `telefonos` varchar(100) NOT NULL,
  `status` varchar(250) NOT NULL,
  `anio` varchar(50) NOT NULL,
  PRIMARY KEY (`id_reinscripcion`),
  UNIQUE KEY `id_reinscripcion` (`id_reinscripcion`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `reinscripcion`
--

INSERT INTO `reinscripcion` (`id_reinscripcion`, `id_alumno`, `carne`, `id_grado`, `observaciones`, `fecha_reinscripcion`, `encargado_reinscripcion`, `telefonos`, `status`, `anio`) VALUES(1, 1, '2010F1', 1, '', '2010-03-20', 'Fidel Ramirez', '5202-5436', 'Inscrito', '2010');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `secciones`
--

CREATE TABLE IF NOT EXISTS `secciones` (
  `id_seccion` int(50) NOT NULL AUTO_INCREMENT,
  `id_grado` int(50) NOT NULL,
  `nombre_seccion` varchar(1000) NOT NULL,
  PRIMARY KEY (`id_seccion`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `secciones`
--

INSERT INTO `secciones` (`id_seccion`, `id_grado`, `nombre_seccion`) VALUES(1, 1, 'A');
INSERT INTO `secciones` (`id_seccion`, `id_grado`, `nombre_seccion`) VALUES(2, 1, 'B');
