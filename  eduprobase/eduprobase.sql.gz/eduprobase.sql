-- phpMyAdmin SQL Dump
-- version 3.3.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 26, 2010 at 02:09 PM
-- Server version: 5.1.41
-- PHP Version: 5.3.2-1ubuntu4.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `eduprobase`
--

-- --------------------------------------------------------

--
-- Table structure for table `alumno`
--

CREATE TABLE IF NOT EXISTS `alumno` (
  `id_alumno` int(50) NOT NULL AUTO_INCREMENT,
  `carne` varchar(250) NOT NULL,
  `codigo_alumno` varchar(50) NOT NULL,
  `nombre_alumno` varchar(250) NOT NULL,
  `apellido` varchar(250) NOT NULL,
  `direccion` varchar(250) NOT NULL,
  `orden` varchar(250) NOT NULL,
  `registro` varchar(250) NOT NULL,
  `fecha` date NOT NULL,
  `telefono1` varchar(250) NOT NULL,
  `edad` varchar(200) NOT NULL,
  `sexo` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `padre` varchar(250) NOT NULL,
  `madre` varchar(250) NOT NULL,
  `encargado` varchar(250) NOT NULL,
  `profesion` varchar(500) NOT NULL,
  `labora` varchar(500) NOT NULL,
  `direccion_labora` varchar(255) NOT NULL,
  `dpi` varchar(50) NOT NULL,
  `extendida` varchar(500) NOT NULL,
  `emergencia` varchar(250) NOT NULL,
  `telefono2` varchar(250) NOT NULL,
  `status` varchar(250) NOT NULL,
  `id_grado` int(50) NOT NULL,
  PRIMARY KEY (`id_alumno`),
  UNIQUE KEY `id_alumno` (`id_alumno`,`carne`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=558 ;

--
-- Dumping data for table `alumno`
--


-- --------------------------------------------------------

--
-- Table structure for table `areas_cursos`
--

CREATE TABLE IF NOT EXISTS `areas_cursos` (
  `id_area` int(50) NOT NULL AUTO_INCREMENT,
  `nombre_area` varchar(250) NOT NULL,
  `observacion_area` text NOT NULL,
  PRIMARY KEY (`id_area`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `areas_cursos`
--


-- --------------------------------------------------------

--
-- Table structure for table `area_ocupacional`
--

CREATE TABLE IF NOT EXISTS `area_ocupacional` (
  `id_ocupacion` int(50) NOT NULL AUTO_INCREMENT,
  `nombre_ocupacion` varchar(250) NOT NULL,
  `observacion` varchar(500) NOT NULL,
  PRIMARY KEY (`id_ocupacion`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `area_ocupacional`
--


-- --------------------------------------------------------

--
-- Table structure for table `catedratico`
--

CREATE TABLE IF NOT EXISTS `catedratico` (
  `id_catedratico` int(50) NOT NULL AUTO_INCREMENT,
  `registro` varchar(100) NOT NULL,
  `nombre_catedratico` varchar(250) NOT NULL,
  `apellido` varchar(250) NOT NULL,
  `profesion` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `telefono` varchar(250) NOT NULL,
  `direccion` varchar(250) NOT NULL,
  `observacion` mediumtext NOT NULL,
  `status` varchar(250) NOT NULL,
  PRIMARY KEY (`id_catedratico`),
  UNIQUE KEY `id_catedratico` (`id_catedratico`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `catedratico`
--


-- --------------------------------------------------------

--
-- Table structure for table `cursos`
--

CREATE TABLE IF NOT EXISTS `cursos` (
  `id_curso` int(50) NOT NULL AUTO_INCREMENT,
  `id_area` int(50) NOT NULL,
  `nombre_curso` varchar(250) NOT NULL,
  `capacidad` varchar(50) NOT NULL,
  `fecha` date NOT NULL,
  `status` varchar(250) NOT NULL,
  `id_grado` int(50) NOT NULL,
  `id_catedratico` int(50) NOT NULL,
  PRIMARY KEY (`id_curso`),
  UNIQUE KEY `id_curso` (`id_curso`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=44 ;

--
-- Dumping data for table `cursos`
--


-- --------------------------------------------------------

--
-- Table structure for table `examenes`
--

CREATE TABLE IF NOT EXISTS `examenes` (
  `id_examen` int(50) NOT NULL AUTO_INCREMENT,
  `examen` varchar(250) NOT NULL,
  `observacion` varchar(250) NOT NULL,
  `status` varchar(250) NOT NULL,
  `fecha_ingreso` date NOT NULL,
  PRIMARY KEY (`id_examen`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `examenes`
--


-- --------------------------------------------------------

--
-- Table structure for table `faltas`
--

CREATE TABLE IF NOT EXISTS `faltas` (
  `id_falta` int(50) NOT NULL AUTO_INCREMENT,
  `id_alumno` int(50) NOT NULL,
  `falta` mediumtext NOT NULL,
  `tipo_falta` varchar(250) NOT NULL,
  `anio_falta` varchar(50) NOT NULL,
  `fecha_falta` date NOT NULL,
  PRIMARY KEY (`id_falta`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=46 ;

--
-- Dumping data for table `faltas`
--


-- --------------------------------------------------------

--
-- Table structure for table `grado`
--

CREATE TABLE IF NOT EXISTS `grado` (
  `id_grado` int(50) NOT NULL AUTO_INCREMENT,
  `fecha_grado` varchar(50) NOT NULL,
  `nombre` varchar(250) NOT NULL,
  `seccion` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY (`id_grado`),
  UNIQUE KEY `id_grado` (`id_grado`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `grado`
--


-- --------------------------------------------------------

--
-- Table structure for table `notas`
--

CREATE TABLE IF NOT EXISTS `notas` (
  `id_nota` int(50) NOT NULL AUTO_INCREMENT,
  `id_alumno` int(50) NOT NULL,
  `id_grado` int(50) NOT NULL,
  `id_curso` int(50) NOT NULL,
  `id_bimestre` int(50) NOT NULL,
  `nota` int(50) NOT NULL,
  `nota2` int(50) NOT NULL,
  PRIMARY KEY (`id_nota`),
  UNIQUE KEY `id_nota` (`id_nota`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6675 ;

--
-- Dumping data for table `notas`
--


-- --------------------------------------------------------

--
-- Table structure for table `ocupacion_alumno`
--

CREATE TABLE IF NOT EXISTS `ocupacion_alumno` (
  `id_relacion` int(50) NOT NULL AUTO_INCREMENT,
  `id_ocupacion` int(50) NOT NULL,
  `id_alumno` int(50) NOT NULL,
  PRIMARY KEY (`id_relacion`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `ocupacion_alumno`
--


-- --------------------------------------------------------

--
-- Table structure for table `reinscripcion`
--

CREATE TABLE IF NOT EXISTS `reinscripcion` (
  `id_reinscripcion` int(50) NOT NULL AUTO_INCREMENT,
  `id_alumno` int(50) NOT NULL,
  `carne` varchar(250) NOT NULL,
  `id_grado` int(50) NOT NULL,
  `id_seccion` int(11) NOT NULL,
  `observaciones` mediumtext NOT NULL,
  `fecha_reinscripcion` date NOT NULL,
  `encargado_reinscripcion` varchar(250) NOT NULL,
  `telefonos` varchar(100) NOT NULL,
  `status` varchar(250) NOT NULL,
  `anio` varchar(50) NOT NULL,
  PRIMARY KEY (`id_reinscripcion`),
  UNIQUE KEY `id_reinscripcion` (`id_reinscripcion`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=558 ;

--
-- Dumping data for table `reinscripcion`
--


-- --------------------------------------------------------

--
-- Table structure for table `secciones`
--

CREATE TABLE IF NOT EXISTS `secciones` (
  `id_seccion` int(50) NOT NULL AUTO_INCREMENT,
  `id_grado` int(50) NOT NULL,
  `nombre_seccion` varchar(50) NOT NULL,
  PRIMARY KEY (`id_seccion`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `secciones`
--


-- --------------------------------------------------------

--
-- Table structure for table `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `id_usuario` int(50) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(250) NOT NULL,
  `usuario` varchar(50) NOT NULL,
  `password` varchar(25) NOT NULL,
  `fecha` date NOT NULL,
  PRIMARY KEY (`id_usuario`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `usuarios`
--

